

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author phuon
 */
public class Node {

    Person value;
    Node next;

    public Node(Person value) {
        this.value = value;
        next = null;
    }
}
