
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author phuon
 */
public class MyLinkedList implements LinkedList {

    Node head, tail;
    int size;

    public MyLinkedList() {
        head = tail = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void display() {
        Node cur = head;
        while (cur != null) {
            System.out.println(cur.value.toString() + " ");
            cur = cur.next;
        }
    }

    @Override
    public void add(Person value) {

        Node node = new Node(value);
        if (isEmpty()) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
        size++;
    }

    @Override
    public void delete(int index) {
        if (index == 0) {
            head = head.next;
            size--;
        }
        if (index == size - 1) {
            Node beforeTail = head;
            while (beforeTail.next != tail) {
                beforeTail = beforeTail.next;
            }
            beforeTail.next = null;
            tail = beforeTail;
            size--;

        }
        if (index > 0 && index < size - 1) {
            int count = 0;
            Node cur = head;
            while (count != index - 1) {
                cur = cur.next;
                count++;
            }
            cur.next = cur.next.next;
            size--;
        }
    }

    @Override
    public Person get(int index) {
        if (index == 0) {
            return (Person) head.value;
        }
        if (index == size - 1) {
            return (Person) tail.value;
        }
        if (index > 0 && index < size - 1) {
            int i = 0;
            Node cur = head;
            while (i != index) {
                cur = cur.next;
                i++;
            }
            return (Person) cur.value;
        } else {
            return null;
        }
    }

    public void addFirst(Person value) {
        Node node = new Node(value);
        if (isEmpty()) {
            head = tail = node;
        } else {
            node.next = head;
            head = node;
        }
        size++;
    }

    public void addIndex(Person value, int index) {
        if (index <= 0) {
            addFirst(value);
        }
        if (index >= size) {
            add(value);
        }
        int count = 0;
        Node cur = head;
        while (cur != null && count != index - 1) { // lap cho den index-1 ~> cur = cur tai vi tri index
            count++;
            cur = cur.next;
        }

        Node node = new Node(value);
        node.next = cur.next;
        cur.next = node;
        size++;
    }

    public void deleteFirst() {
        if (!isEmpty()) {
            head = head.next;
            size--;
        }
    }

    public void deleteLast() {
        if (!isEmpty()) {
            Node cur = head;
            while (cur.next.next != null) {
                cur = cur.next;
            }
            cur.next = null;
            tail = cur;
            size--;
        }
    }

    public Node getNode(int index) {
        if (index == 0) {
            return head;
        }
        if (index == size - 1) {
            return tail;
        }
        if (index > 0 && index < size - 1) {
            int i = 0;
            Node cur = head;
            while (i != index) {
                cur = cur.next;
                i++;
            }
            return cur;
        } else {
            return null;
        }
    }

    public void addFirstNonVowels(Person p) {
        String firstChar;
        firstChar = p.getName().substring(0, 1);
        String vowels = "aiueoAIOUEO";
        if (!vowels.contains(firstChar)) {
            addFirst(p);
        }
    }

    public void addLastNonVowels(Person p) {
        String firstChar;
        firstChar = p.getName().substring(0, 1);
        String vowels = "aiueoAIOUEO";
        if (!vowels.contains(firstChar)) {
            add(p);
        }
    }
    
    public void clearLastNonVowels() {
        for (int i = 0; i < size; i++) {
            Person p = get(i);
            String name = p.getName();
            int length = name.length();
            String lastChar = name.substring(length - 1, length);
            String vowels = "aiueoAIOUEO";
            if (!vowels.contains(lastChar)) {
                delete(i);
                i--;
            }
        }
    }

    public void sortByName() { // bubble sort
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size - 1 - i; j++) {
                Node lhs = getNode(j);
                Node rhs = getNode(j + 1);
                if (lhs.value.compareTo(rhs.value) > 0) {
                    Person temp = lhs.value;
                    lhs.value = rhs.value;
                    rhs.value = temp;
                }
            }
        }
    }

    public void deleteMaxAndAddFirst() {
        int maxAge = head.value.getAge();
        Person maxPerson = head.value;
        int maxIndex = 0;

        int count = 1;
        Node cur = head.next;
        while (cur != null) {
            int age = cur.value.getAge();
            if (age > maxAge) {
                maxAge = age;
                maxIndex = count;
                maxPerson = cur.value;
            }
            count++;
            cur = cur.next;
        }
        System.out.println("Max Person is: " + maxPerson.toString());
        System.out.println("After move to first:");
        
        
        // move to first = delete + addFirst
        delete(maxIndex);
        addFirst(maxPerson);
        display();
    }

    public void deleteMinAndAddLast() {
        int minAge = head.value.getAge();
        Person minPerson = head.value;
        int minIndex = 0;

        int count = 1;
        Node cur = head.next;
        while (cur != null) {
            int age = cur.value.getAge();
            if (age < minAge) {
                minAge = age;
                minIndex = count;
                minPerson = cur.value;
            }
            count++;
            cur = cur.next;
        }
        System.out.println("Min Person is: " + minPerson.toString());
        System.out.println("After move to last:");
        
        // move to last = delete + addLast
        delete(minIndex);
        add(minPerson);
        display();
    }
}
