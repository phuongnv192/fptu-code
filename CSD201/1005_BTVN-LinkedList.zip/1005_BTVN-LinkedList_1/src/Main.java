

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author phuon
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyLinkedList list = new MyLinkedList();
        list.addFirstNonVowels(new Person("A89", "zahra", 22));
        list.addFirstNonVowels(new Person("A31", "eddie", 20));
        list.addFirstNonVowels(new Person("A03", "polly", 45));
        list.addFirstNonVowels(new Person("A24", "lucie", 36));
        list.addFirstNonVowels(new Person("A71", "taylor", 18));
        list.addFirstNonVowels(new Person("A54", "eloise", 25));
        list.addFirstNonVowels(new Person("A91", "paula", 37));
        list.addFirstNonVowels(new Person("A88", "sam", 19));
        list.addFirstNonVowels(new Person("A27", "polly", 31));
        list.addFirstNonVowels(new Person("A25", "mabel", 28));
        list.addFirstNonVowels(new Person("A47", "taylor", 15));
        list.addFirstNonVowels(new Person("A61", "alice", 34));
        list.addFirstNonVowels(new Person("A26", "florence", 23));
        list.addFirstNonVowels(new Person("A02", "jean", 27));
        list.addFirstNonVowels(new Person("A78", "polly", 21));
        list.addFirstNonVowels(new Person("A28", "lily", 32));
        System.out.println("f1:");
        list.display();
        
        
//        list.clearLastNonVowels();
//        System.out.println("\nf2:");
//        list.display();
        
        list.sortByName();
        System.out.println("\nf3:");
        list.display();
        
        System.out.println("\nf4:");
        list.deleteMaxAndAddFirst();
        //list.deleteMinAndAddLast();
    }

}
