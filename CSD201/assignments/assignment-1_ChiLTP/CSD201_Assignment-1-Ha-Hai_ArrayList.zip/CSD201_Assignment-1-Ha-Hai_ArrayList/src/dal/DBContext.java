/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import entity.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author phuon
 */
public class DBContext {

    List<Customer> customers = new ArrayList<>();
    List<Phone> phones = new ArrayList<>();

    public DBContext() {
        importCustomers();
        importPhones();
    }

    private void importCustomers() {
        File f = new File("data\\customer.dat");
        FileReader fr = null;
        try {
            fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String raw = br.readLine();
            while (raw != null && raw.trim().length() > 0) {
                String[] attributes = raw.split(";");
                if (attributes.length == 2) {
                    try {
                        String name = attributes[0];
                        long phoneNumber = Long.parseLong(attributes[1].trim());
                        Customer c = new Customer(name, phoneNumber);
                        customers.add(c);
                        raw = br.readLine();
                    } catch (NumberFormatException e) {
                        break; // wrong phone number ~> exit loop ~> exit import
                    }
                } else {
                    break;
                }
            }
        } catch (FileNotFoundException ex) {
            try {
                f.createNewFile();
            } catch (IOException ex1) {
                Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } catch (IOException ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fr.close();
            } catch (IOException ex) {
                Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void importPhones() {
        File f = new File("data\\phone.dat");
        FileReader fr = null;
        try {
            fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String raw = br.readLine();
            while (raw != null && raw.trim().length() > 0) {
                String[] attributes = raw.split(" ");
                if (attributes.length == 5) {
                    try {
                        long phoneNumber = Long.parseLong(attributes[0]);
                        int duration = Integer.parseInt(attributes[1]);
                        SimpleDateFormat sdfTime = new SimpleDateFormat("HH.mm");
                        Date startTime = sdfTime.parse(attributes[2]);
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
                        Date callingDate = sdfDate.parse(attributes[3]);
                        Region region = Region.valueOf(attributes[4]);
                        Phone p = new Phone(phoneNumber, duration, startTime, callingDate, region);
                        phones.add(p);
                        raw = br.readLine();
                    } catch (IOException | NumberFormatException | ParseException e) {
                        break; // wrong format ~> exit loop ~> exit import
                    }
                } else {
                    break;
                }
            }
        } catch (FileNotFoundException ex) {
            try {
                f.createNewFile();
            } catch (IOException ex1) {
                Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } catch (IOException ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fr.close();
            } catch (IOException ex) {
                Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private Customer getCustomer(long phoneNumber) {
        for (Customer cus : customers) {
            if (cus.getPhoneNumber() == phoneNumber) {
                return cus;
            }
        }
        return null;
    }

    public void PhoneAnalyze() {
        for (Phone p : phones) {
            long phoneNumber = p.getPhoneNumber();
            Customer cus = getCustomer(phoneNumber);
            if (cus != null) {
                cus.addPhone(p);
            }
        }
    }

    public void exportResult() {
        File f = new File("data\\result.dat");
        FileWriter fw = null;
        try {
            fw = new FileWriter(f, false);
            for (Customer c : customers) {
                List<Phone> phones = c.getPhones();
                long total = 0;
                int countNH = 0;
                int countLC = 0;
                int countX = 0;
                int countRX = 0;
                for (Phone p : phones) {
                    total += p.getCostPerCall();
                    switch (p.getRegion()) {
                        case NH: {
                            countNH++;
                            break;
                        }
                        case LC: {
                            countLC++;
                            break;
                        }
                        case X: {
                            countX++;
                            break;
                        }
                        case RX: {
                            countRX++;
                            break;
                        }
                    }
                }

                String line = c.getName() + "; "
                        + c.getPhoneNumber() + " "
                        + total + " "
                        + "NH:" + countNH + " "
                        + "LC:" + countLC + " "
                        + "X:" + countX + " "
                        + "RX:" + countRX + "\n";
                fw.write(line);
            }
        } catch (IOException ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fw.close();
            } catch (IOException ex) {
                Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
