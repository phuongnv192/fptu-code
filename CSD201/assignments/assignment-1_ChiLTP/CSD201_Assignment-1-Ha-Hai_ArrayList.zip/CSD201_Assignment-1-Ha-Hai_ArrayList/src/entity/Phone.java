/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author phuon
 */
public class Phone {

    private long phoneNumber;
    private int duration;
    private Date startTime;
    private Date callingDate;
    private Region region;

    public Phone(long phoneNumber, int duration, Date startTime, Date callingDate, Region region) {
        this.phoneNumber = phoneNumber;
        this.duration = duration;
        this.startTime = startTime;
        this.callingDate = callingDate;
        this.region = region;
    }

    public long getCostPerCall() {
        int regionalCofficient = 0;
        switch (region) {
            case NH: {
                regionalCofficient = 1;
                break;
            }
            case LC: {
                regionalCofficient = 2;
                break;
            }
            case X: {
                regionalCofficient = 3;
                break;
            }
            case RX: {
                regionalCofficient = 4;
                break;
            }
            
        }
        long cost = 400 * (long) duration * (long) regionalCofficient;
        SimpleDateFormat sdfWeekDay = new SimpleDateFormat("EEE");
        String weekDay = sdfWeekDay.format(callingDate);
        int callTime = startTime.getHours();
        if (weekDay.equals("Sat") || weekDay.equals("Sun") || callTime >= 23 || callTime <= 5) {
            cost *= 0.7;
        }
        return cost;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getCallingDate() {
        return callingDate;
    }

    public void setCallingDate(Date callingDate) {
        this.callingDate = callingDate;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public Region getRegion() {
        return region;
    }
}
