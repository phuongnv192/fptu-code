/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LinkedList;

/**
 *
 * @author phuon
 */
public class MyLinkedList<T> implements LinkedList<T> {

    Node<T> head, tail;
    int size;

    public MyLinkedList() {
        head = tail = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void add(T data) {
        Node node = new Node(data);
        if (isEmpty()) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
        size++;
    }

    @Override
    public void delete(T data) {
        if (!isEmpty()) {
            Node before = head;
            while (before != tail) {
                if (before.next.data.equals(data)) {
                    break;
                } else {
                    before = before.next;
                }
            }
            if (before != tail) {
                before.next = before.next.next;
                size--;
            }
        }
    }

    @Override
    public T get(int index) {
        if (index > size - 1 || index < 0 || isEmpty()) {
            return null;
        } else {
            int i = 0;
            Node cur = head;
            while (i != index) {
                cur = cur.next;
            }
            return (T) cur.data;
        }
    }

}
