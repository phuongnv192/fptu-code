
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author phuon
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyTree tree = new MyTree();
        tree.add(new Car("A", 8));
        tree.add(new Car("B", 4));
        tree.add(new Car("C", 12));
        tree.add(new Car("D", 2));
        tree.add(new Car("E", 6));
        tree.add(new Car("F", 10));
        tree.add(new Car("H", 14));
        tree.add(new Car("I", 1));
        tree.add(new Car("J", 3));
        tree.add(new Car("H", 5));
        tree.add(new Car("I", 7));
        tree.add(new Car("K", 9));
        tree.add(new Car("L", 11));
        tree.add(new Car("M", 13));
        tree.add(new Car("O", 15));
        
//        System.out.println("Preoder");
//        tree.preOrder();
//        System.out.println("\nPostorder");
//        tree.postOrder();
//        System.out.println("\nInorder");
//        tree.inOrder();
        System.out.println("\nBFS");
        tree.BreathFirstOrder();
        
        Node node = tree.getNodebyPrice(12);
        tree.deleteByMerging(node);
        //tree.deleteByCopying(node);
        System.out.println("\nBFS");
        tree.BreathFirstOrder();
        
        node = tree.getNodebyPrice(10);
        tree.leftRotate(node);
        System.out.println("\nBFS");
        tree.BreathFirstOrder();
        
        node = tree.getNodebyPrice(8);
        tree.rightRotate(node);
        System.out.println("\nBFS");
        tree.BreathFirstOrder();
    } 
}
