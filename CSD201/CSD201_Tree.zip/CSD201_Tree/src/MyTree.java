/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author phuon
 */
public class MyTree {

    Node root;

    public MyTree() {
    }

    public boolean isEmpty() {
        return root == null;
    }

    public void add(Car value) {
        Node node = new Node(value);
        if (isEmpty()) {
            root = node;
            return;
        }
        Node cu = root;
        Node father = null;
        while (cu != null) {
            if (cu.value.getPrice() == value.getPrice()) {
                System.out.println("Khong the add " + value + " vao tree");
                return;
            }
            father = cu;
            if (cu.value.getPrice() < value.getPrice()) {
                cu = cu.right;
            } else {
                cu = cu.left;
            }
        }
        if (father.value.getPrice() < value.getPrice()) {
            father.right = node;
        } else {
            father.left = node;
        }
    }

    private void visit(Node n) {
        System.out.println(n.value.toString() + "; ");
    }

    public void preOrder() {
        preOrder(root);
    }

    private void preOrder(Node node) {
        if (node == null) {
            return;
        }
        visit(node);
        preOrder(node.left);
        preOrder(node.right);
    }

    public void postOrder() {
        postOrder(root);
    }

    private void postOrder(Node node) {
        if (node == null) {
            return;
        }
        postOrder(node.left);
        postOrder(node.right);
        visit(node);
    }

    public void inOrder() {
        inOrder(root);
    }

    private void inOrder(Node node) {
        if (node == null) {
            return;
        }
        inOrder(node.left);
        visit(node);
        inOrder(node.right);
    }

    public void BreathFirstOrder() {
        MyQueue queue = new MyQueue();
        queue.enqueue(root);
        while (!queue.isEmpty()) {
            Node node = queue.dequeue();
            if (node.left != null) {
                queue.enqueue(node.left);
            }
            if (node.right != null) {
                queue.enqueue(node.right);
            }
            visit(node);
        }
    }
}
