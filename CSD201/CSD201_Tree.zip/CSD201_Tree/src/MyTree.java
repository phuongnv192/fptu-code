/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author phuon
 */
public class MyTree {

    Node root;

    public MyTree() {
    }

    public boolean isEmpty() {
        return root == null;
    }

    public void add(Car value) {
        Node node = new Node(value);
        if (isEmpty()) {
            root = node;
            return;
        }
        Node cu = root;
        Node father = null;
        while (cu != null) {
            if (cu.value.getPrice() == value.getPrice()) {
                System.out.println("Khong the add " + value + " vao tree");
                return;
            }
            father = cu;
            if (cu.value.getPrice() < value.getPrice()) {
                cu = cu.right;
            } else {
                cu = cu.left;
            }
        }
        if (father.value.getPrice() < value.getPrice()) {
            father.right = node;
        } else {
            father.left = node;
        }
    }

    private Node getNode(Car value) {
        Node cur = root;
        while (cur != null) {
            if (cur.value.compareTo(value) == 0) {
                return cur;
            } else if (cur.value.compareTo(value) > 0) {
                cur = cur.left;
            } else {
                cur = cur.right;
            }
        }
        return null;
    }

    private void visit(Node n) {
        System.out.println(n.value.toString() + "; ");
    }

    public void preOrder() {
        preOrder(root);
    }

    private void preOrder(Node node) {
        if (node == null) {
            return;
        }
        visit(node);
        preOrder(node.left);
        preOrder(node.right);
    }

    public void postOrder() {
        postOrder(root);
    }

    private void postOrder(Node node) {
        if (node == null) {
            return;
        }
        postOrder(node.left);
        postOrder(node.right);
        visit(node);
    }

    public void inOrder() {
        inOrder(root);
    }

    private void inOrder(Node node) {
        if (node == null) {
            return;
        }
        inOrder(node.left);
        visit(node);
        inOrder(node.right);
    }

    public void BreathFirstOrder() {
        MyQueue queue = new MyQueue();
        queue.enqueue(root);
        while (!queue.isEmpty()) {
            Node node = queue.dequeue();
            if (node.left != null) {
                queue.enqueue(node.left);
            }
            if (node.right != null) {
                queue.enqueue(node.right);
            }
            visit(node);
        }
    }

    private Node getParent(Node n) {
        if (n == root) {
            return null;
        }
        Node father = null;
        Node cur = root;
        while (cur != null && cur.value.getPrice() != n.value.getPrice()) {
            father = cur;
            if (cur.value.getPrice() < n.value.getPrice()) {
                cur = cur.right;
            } else {
                cur = cur.left;
            }
        }
//        if (cur == null) {
//            return null;
//        }
        return father;
    }

    public Node getNodebyPrice(double price) {
        Node cur = root;
        while (cur != null) {
            if (cur.value.getPrice() == price) {
                return cur;
            } else if (cur.value.getPrice() > price) {
                cur = cur.left;
            } else {
                cur = cur.right;
            }
        }
        return null;
    }

    public void deleteLeaf(Node n) {
        Node father = getParent(n);
        if (father != null) {
            if (father.left.equals(n)) {
                father.left = null;
            } else {
                father.right = null;
            }
        }
    }

    public void deleteNodeOneChild(Node n) {
        Node father = getParent(n);
        if (father != null) {
            if (father.left.equals(n)) {
                if (n.left != null) {
                    father.left = n.left;
                } else {
                    father.left = n.right;
                }
            } else {
                if (n.left != null) {
                    father.left = n.left;
                } else {
                    father.left = n.right;
                }
            }
        }
    }

    public void deleteByCopying(Node p) { // copy left
        if (p == null || p.left == null) {
            return;
        }
        if (p.left.right == null) {
            p.value = p.left.value;
            p.left = p.left.left;
        } else {
            Node father = p.left;
            Node cur = p.left.right;
            while (cur.right != null) {
                father = cur;
                cur = cur.right;
            }
            p.value = cur.value;
            father.right = cur.left;
        }
    }

//    Node findFather(Node p) {
//        if (p.value.getPrice() == root.value.getPrice()) {
//            return null;
//        }
//        Node father = root;
//        Node cu = root;
//        while (cu != null) {
//            if (cu.value.getPrice() == p.value.getPrice()) {
//                return father;
//            }
//            father = cu;
//            if (cu.value.getPrice() < p.value.getPrice()) {
//                cu = cu.right;
//            } else {
//                cu = cu.left;
//            }
//        }
//        return null;
//    }
    void deleteByMerging(Node p) {
        Node father = getParent(p);
        if (father == null) { // root
            if (p.value.getPrice() == root.value.getPrice()) {
                if (p.left == null) {
                    return;
                }
                Node cu = p.left;
                while (cu.right != null) {
                    cu = cu.right;
                }
                cu.right = p.right;
                root = p.left;
            }
        } else {
            if (p.left == null) {
                return;
            }
            Node cu = p.left;
            while (cu.right != null) {
                cu = cu.right;
            }
            cu.right = p.right;
            if (father.value.getPrice() < p.value.getPrice()) {
                father.right = p.left;
            } else {
                father.left = p.left;
            }
        }
    }

    public void leftRotate(Node p) {
        Node grandpa = getParent(p);
        Node child;
        if (p == null || p.right == null) {
            return;
        } else {
            child = p.right;
            p.right = child.left;
            child.left = p;
        }
        if (grandpa != null) {
            if (grandpa.value.compareTo(p.value) < 0) {
                grandpa.right = child;
            } else {
                grandpa.left = child;
            }
        } else {
            root = child;
        }
    }

    public void rightRotate(Node p) {
        Node grandpa = getParent(p);
        Node child;
        if (p == null || p.left == null) {
            return;
        } else {
            child = p.left;
            p.left = child.right;
            child.right = p;
        }
        if (grandpa != null) {
            if (grandpa.value.compareTo(p.value) < 0) {
                grandpa.right = child;
            } else {
                grandpa.left = child;
            }
        } else {
            root = child;
        }
    }

}
