
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author phuon
 */
public class MyQueue {

    NodeQueue rear, front;

    public MyQueue() {
        rear = front = null;
    }

    public boolean isEmpty() {
        return rear == null && front == null;
    }

    public void enqueue(Node node) { // add to the last
        NodeQueue nodeQueue = new NodeQueue(node);
        if (isEmpty()) {
            rear = front = nodeQueue;
        } else {
            rear.next = nodeQueue;
            rear = nodeQueue;
        }
    }

    public Node dequeue() { // delete at first
        NodeQueue nodeQueue = null;
        if (!isEmpty()) {
            nodeQueue = front;
            if (rear != front) {
                front = front.next;
            } else {
                front = rear = null;
            }
        }
        return nodeQueue.value;
    }

    void display() {
        NodeQueue cur = front;
        while (cur != null) {
            System.out.println(cur.value + " ");
            cur = cur.next;
        }
    }
}

class NodeQueue {

    Node value;
    NodeQueue next;

    public NodeQueue(Node value) {
        this.value = value;
        next = null;
    }
}
