

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author phuon
 */
public class Car implements Comparable<Car> {

    private String name;
    private double price;

    public Car() {
    }

    public Car(String Name, double Price) {
        this.name = Name;
        this.price = Price;
    }

    @Override
    public String toString() {
        return "(" + name + ", " + price + ")";
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = Name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double Price) {
        this.price = Price;
    }

    @Override
    public int compareTo(Car o) {
        return (int) (this.price - o.price);
    }

}
